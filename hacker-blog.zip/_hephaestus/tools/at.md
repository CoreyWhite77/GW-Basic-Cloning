---
layout: page
title: at.exe
grand_parent: Overview
parent: Tools
nav_order: 100
---

# Project 'Hephaestus' - [at.exe](at.zip)

**At Process**

Easily schedule actions to occur *at* a specified time/event.    

## Assumptions

There will be some assumptions made in this documentation.  

- The **at.exe** executable is located in the **C:\Toolbelt** folder.  This folder has been added to the %PATH%.  

## Installation

The following instructions are assumpting that above assumptions.

- Create a **C:\Toolbelt** folder.
- If you were provided with a toolbelt.ini file, place that file into the **C:\Toolbelt** folder.
- Download [at.zip](at.zip) to the **C:\Toolbelt** folder.
- Once downloaded, right click on the downloaded file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Now right click on the downloaded file and choose *Extract All...* menu entry.
- In the *Extract Compressed (Zipped) Folders* window, modify the *Files will be extracted to this folder:" value is set to **C:\Toolbelt**.
- Delete the [at.zip](at.zip) file (the file that was downloaded).
- Now right click on the **at.exe** file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Double click on **at.exe**.
- At this point, you'll most likely encounter a *"Windows protected your PC"* prompt. Click the *Run anyway* button.

It is possible that the installation package is a little behind the most recent version. As such, the first thing that **at.exe** will do is check for a new version. If there is an update pending, it will automatically download (install) the **upgrade.exe** tool and apply the latest update.

If you were not provided a **toolbelt.ini** file and you will need to continue with the *Configure / License* section that follows.  If you were provided with a **toolbelt.ini** file, you can jump down to the *Configure* section.

### Configure License ###

In order to **at.exe** to be licensed/execute, you'll need to modify the **toolbelt.ini** file.  If the file doesn't exist, you can easily create it by simply launching **at.exe**.  Note that the **toolbelt.ini** file should be located in the same folder as **at.exe**.  

You can use any text editor such as NotePad; however, we recommend [Visual Studio Code](https://code.visualstudio.com).  

Once you have the file open, you'll need to modify the following lines under the *license* section.  

- *name* - The licensed first and last name.  
- *email* - The licensed email address.  
- *calls* - The call letters of the licensed station.  
- *key* - The provided license key that matches the associated name/email/calls.  

Please note that this file is not *hot reload* enabled; meaning that any tools that need this configuration file will need to be restarted manually in order for the changes to take affect.  

## Configure

In order to execute actions based on specified events, you'll need to provide a schedule.  The schedule file is simply a text file that contains a command to be executed based on a particular event (time, startup, shutdown, file change, etc.). Each line represents a individual event / execute command entry.  

`time 9am run something.exe --argument1 value`

At 9am execute *something.exe* with the desired argument(s).  

`time 0900 days Monday run ftpsync.exe`

At 9am every Monday execute the **ftpsync.exe** tool.  

`time 09:00:00 days M-Su run ftpsync.exe`

At 9am every Monday through Sunday execute the **ftpsync.exe** tool.  

`time 9a every M,W,F run ftpsync.exe`

At 9am every Monday, Wednesday, Friday execute the **ftpsync.exe** tool.  

`time 9a days 1 run ftpsync.exe`

At 9am every 1st day of the month execute the **ftpsync.exe** tool.  

`time 9a days 1,15 run ftpsync.exe`

At 9am every 1st and 15th day of the month execute the **ftpsync.exe** tool.  

`time 9a days 12/25 chdir c:\test run ftpsync.exe`

At 9am every December 25th execute the **ftpsync.exe** tool; but before doing so, change the current folder to **c:\test**.  

`time 9a chdir c:\logs run download.exe http://www.somewhere.com/logs/%--yyMMdd%.log`

At 9am every day execute the **download.exe** tool using the URL that contains a custom date value - this case, yesterday; but before doing so, change the current folder to **c:\logs**.  

`interval 5:00 run ...`

On an interval of 5 minutes, run ...  

`interval 5m days M run ...`

On an interval of 5 minutes every Monday, run ...  

`interval 5m times 9a-5p run ...`

On an interval of 5 minutes between the times 9a-5p, run ...  

`interval 5m dates 12/1-12/31 run ...`

On an interval of 5 minutes for the month of December, run ...  

`folder c:\audio run play.exe %file%`

Whenever an individual file is changed in the specified folder, execute *play.exe* with the name of the file that was changed (*{file}*).  

**schedule file**

It is recommended that the schedule be named using *at* as the file extension. See the *Commands* section (below) for how to utilize the schedule file.  

## Commands

By default, **at.exe** assumes that you will be processing a **default.at** file in the same folder as **at.exe**.  It is possible, however, to launch different instances of **at.exe** with different schedule files.  

`at.exe default.at`  

Do do so, simply pass the name of the schedule file on the command-line.

## Additional Information

[End User License Agreement](/License)  