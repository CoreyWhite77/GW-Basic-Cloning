---
layout: page
title: ta.exe
grand_parent: Overview
parent: Tools
nav_order: 170
---

## Project 'Hephaestus' - [ta.exe](ta.zip) ##

**Time Announce Process**

Want your station to sound more local?  Want your listeners to believe that there is someone on the other side of the dial 24/7?  This is the tool to use... regardless of the automation system you currently have.

This tool provides a means to utilize a collection of *timed audio assets* to generate a target audio file (cut #) for the automation system to play.  

There are several ways that including timed content (time announce) as part of your branding:  

- Station ID.  
- Openers/intros to news, weather, birthday announcements, obits, etc.  

### Assumptions ###

There will be some assumptions made in this documentation.  

- The **ta.exe** executable is located in the C:\Toolbelt folder.  This folder has been added to the %PATH%.  
- The audio assets needed will be located in the C:\ToolBelt\Time folder.  

### Installation ###

The following instructions are assumpting that above assumptions.

- Create a **C:\Toolbelt** folder.
- If you were provided with a toolbelt.ini file, place that file into the **C:\Toolbelt** folder.
- Download [ta.zip](/Install/TOOLBELT/ta.zip) to the **C:\Toolbelt** folder.
- Once downloaded, right click on the downloaded file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Now right click on the downloaded file and choose *Extract All...* menu entry.
- In the *Extract Compressed (Zipped) Folders* window, modify the *Files will be extracted to this folder:" value is set to **C:\Toolbelt**.
- Delete the [ta.zip](/Install/TOOLBELT/ta.zip) file (the file that was downloaded).
- Now right click on the **ta.exe** file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Double click on **ta.exe**.
- At this point, you'll most likely encounter a *"Windows protected your PC"* prompt. Click the *Run anyway* button.

It is possible that the installation package is a little behind the most recent version. As such, the first thing that **ta.exe** will do is check for a new version. If there is an update pending, it will automatically download (install) the **upgrade.exe** tool and apply the latest update.

If you were not provided a **toolbelt.ini** file and you will need to continue with the *Configure / License* section that follows.  If you were provided with a **toolbelt.ini** file, you can jump down to the *Configure "Minion(s)"* section.

### Configure License ###

In order to **ta.exe** to be licensed/execute, you'll need to modify the **toolbelt.ini** file.  If the file doesn't exist, you can easily create it by simply launching **ta.exe**.  Note that the **toolbelt.ini** file should be located in the same folder as **ta.exe**.  

You can use any text editor such as NotePad; however, we recommend [Visual Studio Code](https://code.visualstudio.com).  

Once you have the file open, you'll need to modify the following lines under the *license* section.  

- *name* - The licensed first and last name.  
- *email* - The licensed email address.  
- *calls* - The call letters of the licensed station.  
- *key* - The provided license key that matches the associated name/email/calls.  

Please note that this file is not *hot reload* enabled; meaning that any tools that need this configuration file will need to be restarted manually in order for the changes to take affect.  

### Configure "Minion(s)" (Required) ###

The **ta.exe** utility is capable of running several configuration sets ("minions") providing for a ton of flexibility for how you want to handle time announce.  

To configure the individual time announce minions, you will need to create/modify the ta.ini file.

Each minion is named *minion* followed by a number starting with one (*1*).  Although there isn't a fixed limit to the number of minions that can be configured, there is a reasonable limit of how many can be managed in ones head.  However, the minions do need to be sequential - if there is a gap in the numbers, the application will stop looking for additional minions.  

In each *minion* section...

- *name* - Each minion can be identified with a *friendly* name; this is only used to assist the reader.  
- *active* - If this value is blank, then it attempts to run 24 hours a day.  If you wish to limit the time(s) that it can run, you can do so by specifying the time range in **HHMM-HHMM** format.  Additionally, you can add multiple time ranges separated by commas. Other values supported are: Yes, Y, True, 1, No, N, False, 0. 
- *input* - This is the file path to where the time announch audio assets are located.  
- *output* - This is the target file path and name; this is usually a specific *cart number* named file located in your automation systems audio asset folder.  

Note: Modifying the ta.ini file is *hot reload* enabled; meaning that as soon as you save the changes to the file, the application (if running) will automatically apply the changes (without requiring restart).  

### Configure *Options* (Optional) ###

To configure the time announce options, you will need to create/modify the ta.ini file. If the file doesn't exist, you can easily create it by simply launching **ta.exe**.  Note that the ta.ini file should be located in the same folder as **ta.exe**.  

Under the *options* section...  

- *offset* - This option allows you to *fudge the clock* by a small amount in order to generate the appropriate target file a few seconds prior to needing it in order to accomidate any possible delays associated with the target automation system. In most circumstances, this value should be left at the default of 0 seconds. 

Note: Modifying the ta.ini file is *hot reload* enabled; meaning that as soon as you save the changes to the file, the application (if running) will automatically apply the changes (without requiring restart).  

### Audio Assets (Required) ###

The timed audio assets are audio files that are (typically) recorded by your voice professionals using whatever tools you are already familiar with.  These can simply contain something similar to:

`It's Five Twenty-Three on Hits 106.`

With that said, you are limited to your imagination as to what is included (or not).

Once you have this content, the timed audio assets are to be placed in the *input* folder and named using the hhMM.wav pattern where hh is the two digit 12-hour clock hour and MM is the two digit minute. When the application is running it will attempt to generate the *output* using the timed audio asset as the source file (created/replaced).  If the file doesn't exist, then the output file will be removed (deleted) to insure that the wrong timed audio asset isn't accidentially aired.  

#### *Missing* (Optional) ####

Under default circumstances, if the timed audio asset is not available, the target will be *cleared* (deleted) in order to insure that the wrong audio doesn't air.  It is possible to specify a *placeholder* audio asset file instead of having *nothing*.  To do so, place a missing.wav file in the *input* folder for the target minion entry. If the timed audio asset doesn't exist, then the missing.wav file will be used instead allowing for there to always be *something* that can air when called upon.  

Note: Adding, removing, modifying these timed audio assets (and/or placeholder) takes *immediate* affect; meaning that the next time something needs to take place (every minute), any new/modified files will be considered in the execution of the current task.  

### Additional Information ###

[Radio Toolbelt Index](/docs/hephaestus)  
[Release Notes](/docs/hephaestus/releasenotes)  
[End User License Agreement](/License)  