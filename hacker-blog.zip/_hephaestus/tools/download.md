---
layout: page
title: download.exe
grand_parent: Overview
parent: Tools
nav_order: 130
---

## Project 'Hephaestus' - [download.exe](download.zip) ##

**Download Tool**

Easily download a file off of the internet (HTTP/HTTPS) from the command-line.      

### Assumptions ###

There will be some assumptions made in this documentation.  

- The **download.exe** executable is located in the **C:\Toolbelt** folder.  This folder has been added to the %PATH%.  
- When using **download.exe**, the target folder is the current folder.  

### Installation ###

The following instructions are assumpting that above assumptions.

- Create a **C:\Toolbelt** folder.
- If you were provided with a toolbelt.ini file, place that file into the **C:\Toolbelt** folder.
- Download [download.zip](/Install/TOOLBELT/download.zip) to the **C:\Toolbelt** folder.
- Now right click on the downloaded file and choose *Extract All...* menu entry.
- In the *Extract Compressed (Zipped) Folders* window, modify the *Files will be extracted to this folder:" value is set to **C:\Toolbelt**.
- Delete the [download.zip](/Install/TOOLBELT/download.zip) file (the file that was downloaded).
- Now right click on the **download.exe** file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Double click on **download.exe**.
- At this point, you'll most likely encounter a *"Windows protected your PC"* prompt. Click the *Run anyway* button.

It is possible that the installation package is a little behind the most recent version. As such, the first thing that **download.exe** will do is check for a new version. If there is an update pending, it will automatically download (install) the **upgrade.exe** tool and apply the latest update.

If you were not provided a **toolbelt.ini** file and you will need to continue with the *Configure / License* section that follows.  If you were provided with a **toolbelt.ini** file, you can jump down to the *Configure* section.

### Configure License ###

In order to **download.exe** to be licensed/execute, you'll need to modify the **toolbelt.ini** file.  If the file doesn't exist, you can easily create it by simply launching **download.exe**.  Note that the **toolbelt.ini** file should be located in the same folder as **download.exe**.  

You can use any text editor such as NotePad; however, we recommend [Visual Studio Code](https://code.visualstudio.com).  

Once you have the file open, you'll need to modify the following lines under the *license* section.  

- *name* - The licensed first and last name.  
- *email* - The licensed email address.  
- *calls* - The call letters of the licensed station.  
- *key* - The provided license key that matches the associated name/email/calls.  

Please note that this file is not *hot reload* enabled; meaning that any tools that need this configuration file will need to be restarted manually in order for the changes to take affect.  

### Configure ###

It is possible to modify some of the defaults...

- *(extract)*
- *(delete)*

To do so, you can create a **download.ini** file in the same folder as **download.exe**. These will then modify the default value to these values and specifying them on the command line is no longer necessary; however, if you do provide them on the command line and they are different than what is in **download.ini** file - the information provided on the command line will override the default.

The **download.ini** file should contain the following:

---

[defaults]

extract=false
delete=false

---

### Commands ###

`download (url)`

The **download.exe** tool makes it easy to download a file from the internet using the HTTP/HTTPS protocol.  

`download (tool)`  

The **download.exe** tool makes it simple to add additional tools to the toolbelt.  

- Open command prompt.  
- Change to the **C:\Toolbelt** folder.  
- Type **download (name of the tool) --extract --delete** and press enter.

This will download the tool, automatically extract the tool and then delete the downloaded file.  If you'd like to not have to pass the *--extract* and *--delete* flags, you can modify the **download.ini** file to make these on by default.  

### Additional Information ###

[End User License Agreement](/License)  