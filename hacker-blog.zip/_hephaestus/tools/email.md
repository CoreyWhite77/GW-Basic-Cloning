---
layout: page
title: email.exe
grand_parent: Overview
parent: Tools
nav_order: 140
---

## Project 'Hephaestus' - [email.exe](email.zip) ##

**Email Tool**

Provides simple functionality for sending email via the command-line.  

### Assumptions ###

There will be some assumptions made in this documentation.  

- The **email.exe** executable is located in the **C:\Toolbelt** folder.  This folder has been added to the %PATH%.  

### Installation ###

The following instructions are assumpting that above assumptions.

- Create a **C:\Toolbelt** folder.
- If you were provided with a toolbelt.ini file, place that file into the **C:\Toolbelt** folder.
- Download [email.zip](/Install/TOOLBELT/email.zip) to the **C:\Toolbelt** folder.
- Once downloaded, right click on the downloaded file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Now right click on the downloaded file and choose *Extract All...* menu entry.
- In the *Extract Compressed (Zipped) Folders* window, modify the *Files will be extracted to this folder:" value is set to **C:\Toolbelt**.
- Delete the [email.zip](/Install/TOOLBELT/email.zip) file (the file that was downloaded).
- Now right click on the **email.exe** file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Double click on **email.exe**.
- At this point, you'll most likely encounter a *"Windows protected your PC"* prompt. Click the *Run anyway* button.

It is possible that the installation package is a little behind the most recent version. As such, the first thing that **email.exe** will do is check for a new version. If there is an update pending, it will automatically download (install) the **upgrade.exe** tool and apply the latest update.

If you were not provided a **toolbelt.ini** file and you will need to continue with the *Configure / License* section that follows.  If you were provided with a **toolbelt.ini** file, you can jump down to the *Configure* section.

### Configure License ###

In order to **email.exe** to be licensed/execute, you'll need to modify the **toolbelt.ini** file.  If the file doesn't exist, you can easily create it by simply launching **email.exe**.  Note that the **toolbelt.ini** file should be located in the same folder as **email.exe**.  

You can use any text editor such as NotePad; however, we recommend [Visual Studio Code](https://code.visualstudio.com).  

Once you have the file open, you'll need to modify the following lines under the *license* section.  

- *name* - The licensed first and last name.  
- *email* - The licensed email address.  
- *calls* - The call letters of the licensed station.  
- *key* - The provided license key that matches the associated name/email/calls.  

Please note that this file is not *hot reload* enabled; meaning that any tools that need this configuration file will need to be restarted manually in order for the changes to take affect.  

### Configure ###

Before **email.exe** can actually send an email, it will be necessary to provide the appropriate values in the **email.ini** configuration file for your particular email server/host and account information.  

To do so, you can create a **email.ini** file in the same folder as **email.exe**.

The **email.ini** file should look similar the following:

---

[options]

verbose=True

[from]

name=*(name)*
email=*(email)*

[server]

host=*(host)*
user=*(user)*  
pass=*(pass)*  
port=*(port)*  
ssl=True

---

**options**

- *verbose* - By default (at the time of this writing), the verbose value is set to True; which activates the option to provide more details of what is going on during the overall process.  This can be disabled in order to reduce the associated noise.  

**from**

- *name* - This would be typically be set to first and last name of the associated "person" sending the email.  
- *email* - This is the email address that will be shown to the recipient of the email.  

**server**

- *host* - This is the email server for the email account that will be utilized to send the email through (ie. *smtp.gmail.com*).  
- *user* - The user account *name* for the email account that will be used to send the email (typically an email address).  
- *pass* - The password for the account.  
- *port* - The port number that the server will use to communicate (ie. 587).  
- *ssl* - Most modern email servers require that the communication with the server occur over a *secure connect* (SSL), thus the default of *True*; older servers may need to disable SSL (*False*).  

### Commands ###

**send**

- *--to* - The **to:** address.  Can be formatted as a standard email address or an *outlook-style* email address similar to "First Last &lt;account@server.com&gt;".  
- *--cc* - The **cc:** address (optional).  
- *--bcc* - The **bcc:** address (optional).  
- *--subject* - The summary of the message.  
- *--body* - The actual content of the message.   
- *--html* - Whether or not the body is HTML formatted (optional).   

Please note that any value (*to*, *cc*, *bcc*, *subject*, *body*) that has a value containing one or more spaces will need to be quoted.  

### Additional Information ###

[End User License Agreement](/License)  