---
layout: page
title: weather.exe
grand_parent: Overview
parent: Tools
nav_order: 180
---

## Project 'Hephaestus' - [weather.exe](weather.zip) ##

**Weather Tool**

This utility is primarily for our internal use for diagnosing *Project 'Zeus'* issues as they relate to pulling the information from the various weather providers. Additionally, we utilize this to initially test additional providers. We are including it in the *toobelt* to gather some feedback as to the possible other uses that this might serve.  

### Assumptions ###

There will be some assumptions made in this documentation.  

- The **weather.exe** executable is located in the C:\Toolbelt folder.  This folder has been added to the %PATH%.  

### Installation ###

The following instructions are assumpting that above assumptions.

- Create a **C:\Toolbelt** folder.
- If you were provided with a toolbelt.ini file, place that file into the **C:\Toolbelt** folder.
- Download [weather.zip](/Install/TOOLBELT/weather.zip) to the **C:\Toolbelt** folder.
- Once downloaded, right click on the downloaded file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Now right click on the downloaded file and choose *Extract All...* menu entry.
- In the *Extract Compressed (Zipped) Folders* window, modify the *Files will be extracted to this folder:" value is set to **C:\Toolbelt**.
- Delete the [weather.zip](/Install/TOOLBELT/weather.zip) file (the file that was downloaded).
- Now right click on the **weather.exe** file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Double click on **weather.exe**.
- If you encounter a *"Windows protected your PC"* prompt. Click the *Run anyway* button.

It is possible that the installation package is a little behind the most recent version. As such, the first thing that **weather.exe** will do is check for a new version. If there is an update pending, it will automatically download (install) the **upgrade.exe** tool and apply the latest update.

If you were not provided a **toolbelt.ini** file and you will need to continue with the *Configure / License* section that follows.  If you were provided with a **toolbelt.ini** file, you can jump down to the *Configure* section.

### Configure License ###

In order to **weather.exe** to be licensed/execute, you'll need to modify the **toolbelt.ini** file.  If the file doesn't exist, you can easily create it by simply launching **weather.exe**.  Note that the **toolbelt.ini** file should be located in the same folder as **weather.exe**.  

You can use any text editor such as NotePad; however, we recommend [Visual Studio Code](https://code.visualstudio.com).  

Once you have the file open, you'll need to modify the following lines under the *license* section.  

- *name* - The licensed first and last name.  
- *email* - The licensed email address.  
- *calls* - The call letters of the licensed station.  
- *key* - The provided license key that matches the associated name/email/calls.  

Please note that this file is not *hot reload* enabled; meaning that any tools that need this configuration file will need to be restarted manually in order for the changes to take affect.  

### Configure ###

Most of the following options can easily be changed from within the application in addition to being "hot reload" enabled within the **weather.ini** configuration file.  

**options**  

- *name* - This value will be displayed in the window title.  
- *location* - You can use zip code, lat/lon, NOAA station, etc.  

**startup**

- *location* - initially blank when the file is first created; will be modified to the last position of the window upon exit.  
- *size* - initially blank when the file is first created; will be modified to the last size of the window upon exit.  
- *minimized* - Can be set to True or False. This determines whether or not the window will be launched in a minimized state.  

**current**

The following specify the settings for the "current" conditions.  

- *provider* - Can be set to *nws*, *nwsapi*, *nwsmapclick*, *openweathermap*, *weatherstack*, *pws*, or *yahoo*.  
- *interval* - This is the number of minutes between polling the information from the chosen provider.  

**forecast**

The following are settings as they relate to pulling the forecast (assuming the forecast information is already included as part of the current details).  

- *midnight* - Set to True to activate the information to be retrieved at 12:00 am. False to disable.  
- *morning* - Set to True to activate the information to be retrieved at 6:00 am. False to disable.  
- *noon* - Set to True to activate the information to be retrieved at 12:00 pm. False to disable.   
- *evening* - Set to True to activate the information to be retrieved at 6:00 pm. False to disable.    

Note: Modifying the **weather.ini** file is *hot reload* enabled; meaning that as soon as you save the changes to the file, the application (if running) will automatically apply the changes (without requiring restart).  

### Additional Information ###

[Radio Toolbelt Index](/docs/hephaestus)  
[Release Notes](/docs/hephaestus/releasenotes)  
[End User License Agreement](/License)  