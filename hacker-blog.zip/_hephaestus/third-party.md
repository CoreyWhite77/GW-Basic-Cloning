---
layout: page
title: Third-Party Tools
has_children: true
has_toc: true
parent: Overview
nav_order: 1001
---

# Project 'Hephaestus' - Third-Party Tools

Tools designed for third-party products.

- [djbradio.exe](djbradio) - DJB Radio Radio Automation Tool
- [enco.exe](enco) - Enco Radio Automation Tool
- [nl.exe](nl) - Natural Log Traffic and Billing Tool
- [simian.exe](simian) - Broadcast Software International Simian Radio Automation Tool
- [skylla.exe](skylla) - Smarts Broadcasting Skylla Radio Automation Tool  
- [spl.exe](spl) - Station Playlist Radio Automation Tool

Third-party integration tools are *unofficial* extensions for products that are not designed, sold and supported by Shiny Stone Digital.  These tools are made available to our clients; however, they are to be considered as-is, without warranty of any kind.  Additionally, they should be considered "use at your own risk".  With all of that out of the way, if we can address any issue specific to our tools - we'd absolutely love to do so.  Just please understand that these are all unofficial integrations and subject to changes that are not only beyond our control - but could very well be "blocked" by their respective party.  Additionally, usage of these tools could "void any warranty"; so please consider carefully using these if this is a concern.  Finally, we are completely open to the possibility of transitioning any and all of these tools from "unofficial" to "official" if the respective third-party is willing.  

## Warning / Disclaimer

Unless otherwise noted, several tools work directly with third-party products (not associated in any way with Shiny Stone Digital); as such, these tools are completely "unofficial" and considered AS-IS without any warranty of any kind, express or implied.  

In other words, if they work... they work.  If they don't, they don't.  We will do what we can, but that is all that we can promise. If, however, pressure is applied to these third-parties it is entirely possible that something more "official" can be done. To say this another way... we are more than willing to work with these third-parties if they are receptive to doing so. Until then, we'll do the best we can to address your needs in what capacity is possible.
