---
layout: page
title: Examples
parent: Overview
nav_order: 100
has_children: true
has_toc: true
---

# Project 'Hephaestus' - Examples

- [Download and merge ENCO sports as-play.](download_and_merge_enco_sports_asplay)
- [Upon locking the log, automatically upload DJB Radio log file and send email notification.](upload_djb_radio_log_send_email)
- [Extract DJB Radio 'Shell' and import as new/updated RT template.](djb_radio_shell_to_rt_template)