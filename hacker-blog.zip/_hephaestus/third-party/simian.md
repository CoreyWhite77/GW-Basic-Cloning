---
layout: page
title: simian.exe
grand_parent: Overview
parent: Third-Party Tools
nav_order: 150
---

## Project 'Hephaestus' - [simain.exe](simain.zip)

**Broadcast Software International Simian Radio Automation Tool**

This tool is designed to provide additional features and capabilities to the automation system that are difficult (if not impossible) to do otherwise.

*Disclaimer*

Please understand that this tool has no warranty, express or implied. If you decide to utilize this tool, you do so at your own risk. This is an **unofficial** extension to the third-party product and is **not** supported or endorced by the original product manufacturer.

### Assumptions ###

There will be some assumptions made in this documentation.  

- The **simain.exe** executable is located in the **C:\Toolbelt** folder.  This folder has been added to the %PATH%.  

### Installation ###

The following instructions are assumpting that above assumptions.

- Create a **C:\Toolbelt** folder.
- If you were provided with a toolbelt.ini file, place that file into the **C:\Toolbelt** folder.
- Download [simain.zip](/Install/TOOLBELT/simain.zip) to the **C:\Toolbelt** folder.
- Once downloaded, right click on the downloaded file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Now right click on the downloaded file and choose *Extract All...* menu entry.
- In the *Extract Compressed (Zipped) Folders* window, modify the *Files will be extracted to this folder:" value is set to **C:\Toolbelt**.
- Delete the [simain.zip](/Install/TOOLBELT/simain.zip) file (the file that was downloaded).
- Now right click on the **simain.exe** file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Double click on **simain.exe**.
- At this point, you'll most likely encounter a *"Windows protected your PC"* prompt. Click the *Run anyway* button.

It is possible that the installation package is a little behind the most recent version. As such, the first thing that **simain.exe** will do is check for a new version. If there is an update pending, it will automatically download (install) the **upgrade.exe** tool and apply the latest update.

If you were not provided a **toolbelt.ini** file and you will need to continue with the *Configure / License* section that follows.  If you were provided with a **toolbelt.ini** file, you can jump down to the *Configure* section.

### Configure License ###

In order to **simain.exe** to be licensed/execute, you'll need to modify the **toolbelt.ini** file.  If the file doesn't exist, you can easily create it by simply launching **simain.exe**.  Note that the **toolbelt.ini** file should be located in the same folder as **simain.exe**.  

You can use any text editor such as NotePad; however, we recommend [Visual Studio Code](https://code.visualstudio.com).  

Once you have the file open, you'll need to modify the following lines under the *license* section.  

- *name* - The licensed first and last name.  
- *email* - The licensed email address.  
- *calls* - The call letters of the licensed station.  
- *key* - The provided license key that matches the associated name/email/calls.  

Please note that this file is not *hot reload* enabled; meaning that any tools that need this configuration file will need to be restarted manually in order for the changes to take affect.  

### Configure ###

To prepare to utilize this utility, you'll need to have the path and associated files for each particular task available to the machine you are executing this utility upon.  

### Commands ###

**asplay merge**

The *asplay* command provides abilities to work with the asplay (aired) logs.  

**asplay merge**

With the *asplay merge* sub-command, you can easily merge two asplay (aired) logs.  

`simian.exe asplay merge --primary "c:\traffic\station1\000000.log" --secondary "c:\traffic\station1\sports\000000.log"`

`simian.exe asplay merge --primary "c:\traffic\station1\000000.log" --secondary "c:\traffic\station1\sports"`

`simian.exe asplay merge --primary "c:\traffic\station1\000000.log" --secondary "sports"`

- *primary* - The full path and filename to the primary log to be merged.  
- *secondary* - The secondary file can either be the full path and filename to the second file to be merged or it can contain the full or partial path to the folder containing the secondary file.  

Upon successfully processing the merge, the primary file will be archived with an *.original* extension.  

**asplay merge-all**

With the *asplay merge-all* sub-command, you can easily merge multiple asplay (aired) logs.  

`simian.exe asplay merge-all --primary "c:\traffic\station1" --secondary "c:\traffic\station1\sports"`

`simian.exe asplay merge-all --primary "c:\traffic\station1" --secondary "sports"`

- *primary* - The full path to the primary log(s) to be processed.  
- *secondary* - The secondary path can either be the full path to the second file(s) to be merged or it can contain the partial path to the folder containing the secondary file(s).  

Upon successfully processing the merge, the primary file will be archived with an *.original* extension.  This process will skip files that appear to have already been processed.  

### Additional Information ###

[Radio Toolbelt Index](/docs/hephaestus)  
[Release Notes](/docs/hephaestus/releasenotes)  
[End User License Agreement](/License)  