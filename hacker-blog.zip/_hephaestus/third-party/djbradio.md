---
layout: page
title: djbradio.exe
grand_parent: Overview
parent: Third-Party Tools
nav_order: 100
---

## Project 'Hephaestus' - [djbradio.exe](djbradio.zip) ##

**DJB Radio Tool**

This tool is designed to provide additional features and capabilities to the automation system that are difficult (if not impossible) to do otherwise.

*Disclaimer*

Please understand that this tool has no warranty, express or implied. If you decide to utilize this tool, you do so at your own risk. This is an **unofficial** extension to the third-party product and is **not** supported or endorced by the original product manufacturer.

### Assumptions ###

There will be some assumptions made in this documentation.  

- The **djbradio.exe** executable is located in the **C:\Toolbelt** folder.  This folder has been added to the %PATH%.  

### Installation ###

The following instructions are assumpting that above assumptions.

- Create a **C:\Toolbelt** folder.
- If you were provided with a toolbelt.ini file, place that file into the **C:\Toolbelt** folder.
- Download [djbradio.zip](/Install/TOOLBELT/djbradio.zip) to the **C:\Toolbelt** folder.
- Once downloaded, right click on the downloaded file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Now right click on the downloaded file and choose *Extract All...* menu entry.
- In the *Extract Compressed (Zipped) Folders* window, modify the *Files will be extracted to this folder:" value is set to **C:\Toolbelt**.
- Delete the [djbradio.zip](/Install/TOOLBELT/djbradio.zip) file (the file that was downloaded).
- Now right click on the **djbradio.exe** file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Double click on **djbradio.exe**.
- At this point, you'll most likely encounter a *"Windows protected your PC"* prompt. Click the *Run anyway* button.

It is possible that the installation package is a little behind the most recent version. As such, the first thing that **djbradio.exe** will do is check for a new version. If there is an update pending, it will automatically download (install) the **upgrade.exe** tool and apply the latest update.

If you were not provided a **toolbelt.ini** file and you will need to continue with the *Configure / License* section that follows.  If you were provided with a **toolbelt.ini** file, you can jump down to the *Configure* section.

### Configure License ###

In order to **djbradio.exe** to be licensed/execute, you'll need to modify the **toolbelt.ini** file.  If the file doesn't exist, you can easily create it by simply launching **djbradio.exe**.  Note that the **toolbelt.ini** file should be located in the same folder as **djbradio.exe**.  

You can use any text editor such as NotePad; however, we recommend [Visual Studio Code](https://code.visualstudio.com).  

Once you have the file open, you'll need to modify the following lines under the *license* section.  

- *name* - The licensed first and last name.  
- *email* - The licensed email address.  
- *calls* - The call letters of the licensed station.  
- *key* - The provided license key that matches the associated name/email/calls.  

Please note that this file is not *hot reload* enabled; meaning that any tools that need this configuration file will need to be restarted manually in order for the changes to take affect.  

### Configure ###

It is possible to modify some of the defaults...

- *(base-path)*

To do so, you can create a **djbradio.ini** file in the same folder as **djbradio.exe**. These will then modify the default value to these values and specifying them on the command line is no longer necessary; however, if you do provide them on the command line and they are different than what is in **djbradio.ini** file - the information provided on the command line will override the default.

The **djbradio.ini** file should contain the following:

---

[defaults]

base-path=*(path)*  

---

### Commands ###

The tool allows you to do several actions (commands) and each of these commands can have one or more options (values).  Some options are required while others are optional and/or assume some sort of default.

**shell export**

DJB Radio has a concept of *shells* which define the overall structure of the log to be aired.  It utilizes these *shells* during it's internal *merge* process; where you provide a log from the traffic/music system and DJB Radio then *merges* it into the operating log (automation) using the structure defined within the *shell*.  Each shell is number starting with 1.

Please utilize the Production tool of DJB Radio to review these to determine the *(number)* as required below.

`djbradio shell export (number) --base-path (basePath) --output (filename)`

This is the most direct method of exporting a *shell* out of DJB Radio.  The resulting file is a simple stright-forward CSV formatted file where the first column contains the column names.  This file can then be opened in any text editor or even Excel.  

`djbradio shell export (number) --base-path (basePath) --output (filename) --special (special.csv)`

The *--special* option can be utilized to inject specific avail types (with length) into each break.

**TODO** Need to document this more completely.

### Additional Information ###

[End User License Agreement](/License)  