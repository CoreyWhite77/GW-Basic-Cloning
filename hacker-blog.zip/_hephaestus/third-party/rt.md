---
layout: page
title: rt.exe
grand_parent: Overview
parent: Third-Party Tools
nav_order: 140
---

## Project 'Hephaestus' - [rt.exe](rt.zip)

**RadioTraffic.com Traffic and Billing Tool**

This tool is designed to provide additional features and capabilities to the traffic and billing system that are difficult (if not impossible) to do otherwise.

*Disclaimer*

Please understand that this tool has no warranty, express or implied. If you decide to utilize this tool, you do so at your own risk. This is an **unofficial** extension to the third-party product and is **not** supported or endorced by the original product manufacturer.

### Assumptions ###

There will be some assumptions made in this documentation.  

- The **rt.exe** executable is located in the **C:\Toolbelt** folder.  This folder has been added to the %PATH%.  

### Installation ###

The following instructions are assumpting that above assumptions.

- Create a **C:\Toolbelt** folder.
- If you were provided with a toolbelt.ini file, place that file into the **C:\Toolbelt** folder.
- Download [rt.zip](/Install/TOOLBELT/rt.zip) to the **C:\Toolbelt** folder.
- Once downloaded, right click on the downloaded file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Now right click on the downloaded file and choose *Extract All...* menu entry.
- In the *Extract Compressed (Zipped) Folders* window, modify the *Files will be extracted to this folder:" value is set to **C:\Toolbelt**.
- Delete the [rt.zip](/Install/TOOLBELT/rt.zip) file (the file that was downloaded).
- Now right click on the **rt.exe** file and choose *Properties*.
- In the *Properties* window, find and enabled (check) the *Unblock* value. Click *OK* to close the window.
- Double click on **rt.exe**.
- At this point, you'll most likely encounter a *"Windows protected your PC"* prompt. Click the *Run anyway* button.

It is possible that the installation package is a little behind the most recent version. As such, the first thing that **rt.exe** will do is check for a new version. If there is an update pending, it will automatically download (install) the **upgrade.exe** tool and apply the latest update.

If you were not provided a **toolbelt.ini** file and you will need to continue with the *Configure / License* section that follows.  If you were provided with a **toolbelt.ini** file, you can jump down to the *Configure* section.

### Configure License ###

In order to **rt.exe** to be licensed/execute, you'll need to modify the **toolbelt.ini** file.  If the file doesn't exist, you can easily create it by simply launching **rt.exe**.  Note that the **toolbelt.ini** file should be located in the same folder as **rt.exe**.  

You can use any text editor such as NotePad; however, we recommend [Visual Studio Code](https://code.visualstudio.com).  

Once you have the file open, you'll need to modify the following lines under the *license* section.  

- *name* - The licensed first and last name.  
- *email* - The licensed email address.  
- *calls* - The call letters of the licensed station.  
- *key* - The provided license key that matches the associated name/email/calls.  

Please note that this file is not *hot reload* enabled; meaning that any tools that need this configuration file will need to be restarted manually in order for the changes to take affect.  

### Configure ###

It is possible to modify some of the defaults...

- *(username)*
- *(password)*
- *(station)*

To do so, you can create a **rt.ini** file in the same folder as **rt.exe**. These will then modify the default value to these values and specifying them on the command line is no longer necessary; however, if you do provide them on the command line and they are different than what is in **rt.ini** file - the information provided on the command line will override the default.

The **rt.ini** file should contain the following:

---

[defaults]

user=*(username)*  
pass=*(password)*  
station=*(station)*  

---

### Commands ###

**station**

The *station* command provides a quick way to get a list of the stations associated with the provided username and password combination.

It can also serve as a simple way to validate that the username and password are correct.

`rt.exe station list --user (username) --pass (password)`

(with rt.ini defaults)

`rt.exe station list`

The *(username)* and *(password)* are placeholders where you need to provide your RadioTraffic.com username and password - the same login credentials used when signing into the RadioTraffic.com traffic and billing system.

**template**

`rt.exe template list --station (station) --user (username) --pass (password)`

(with rt.ini defaults)

`rt.exe template list`

Using the *station* command, you can then leverage the *template list* command to get a list of existing template names.

The *(station)* placeholder is where you would provide the name of the station.  If the station name contains spaces, you'll need to use the quotation marks to enclose the name.

`rt.exe template export --station (station) --user (username) --pass (password) --name (template name) --output (filename)`

(with rt.ini defaults)

`rt.exe template export --name (template name) --output (filename)`

Now that we have a list of templates, we can utilize this to export one of the templates to a target file.

The *(template name)* and *(filename)* are to be replaced with the template name you determined from the *template list* command and the target filename that you'd like to write this information to.

`rt.exe template export --station (station) --user (username) --pass (password) --input (filename) --name (template name)`

(with rt.ini defaults)

`rt.exe template export --input (filename) --name (template name)`

It is entirely possible to then use a previously exported template within a text editor (assuming you don't invalidate the overall structure of the file - meaning the right number of commas in the right places with the information between the commas as they should be) and then import those changes back into the traffic and billing system either overwriting the original or creating a new template.

The *(filename)* and *(template name)* are to be replaced with the filename that you are going to import and the desired template name within the traffic and billing system.

### Additional Information ###
