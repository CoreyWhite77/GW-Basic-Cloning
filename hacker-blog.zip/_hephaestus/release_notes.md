---
layout: page
title: Release Notes
parent: Overview
nav_order: 10000
---

# Project 'Hephaestus'

## Release Notes

### ALPHA

- Initial/internal release.  

## A Note

It is important to understand that we adhere to the philosophy of "release early, release often" through a "continuous delivery" model.  What this means to you is that we are extremely enthusiastic to share with you any completed improvements as soon as they are available to that you can take advantage of these NOW!  

This, of course, can't be done without your participation.  It is extremely important that you take a moment to review the latest release notes.  If you have any questions, comments or need additional in-depth assistance with any of the improvements please feel free to reach out to us.  

Thanks.  

Cory Smith

## Additional Information

[End User License Agreement](/License)  