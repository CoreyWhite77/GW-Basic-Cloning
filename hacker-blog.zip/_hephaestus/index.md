---
layout: page
title: Overview
permalink: /hephaestus/
nav_order: 1
has_children: true
has_toc: true
---

# Project 'Hephaestus'

Project 'Hephaestus' is a collection of widgets that can be either run stand-alone or as part of a process chain to accomplish tasks that are extremely difficult (if not, in some cases, impossible) to accomplish without access to these tools.  

This collection of tools not only sees improvements to the existing (included) tools, but new tools are being added all the time. A license to Project 'Hephaestus' provides access to existing and future Project 'Hephaestus' tools.  

## Price

Annual rate of $250 per user/station/machine.  

Project 'Hephaestus' is licensed on a "per station, per user, per machine" basis where a single user is allowed to use the tools on a single station per license basis on up to two install points (machines). 

_Price effective as of October 1st, 2020_  

(Please note that this is an introductory rate available to our *early adopters* and is expected to be adjusted as the product continues to improve/evolve.)

## Install

A few assumptions will be made with regards to how you wish to install/utilize these tools.  The documentation is based on these assumptions.  Adjust accordingly depending on your individual usage scenarios.

- Create a **C:\Toolbelt** folder.

Now that we have the folder where the tools will live, we'll want to modify the **%PATH%** environment variable so that we can access these tools from any command prompt path.

- Press the **WIN+R** (Windows Run) keys to bring up the *Run* window.
- In the *Run* window, type **sysdm.cpl** in the *Open:* field and click the *OK* button.
- This will launch the *System Properties* dialog.  On this dialog, click on the *Advanced* tab.
- On the *Advanced* tab click the *Environment Variables...* button.  
- This will launch the *Environment Variables* window.  In the *User variables for ...* list, find and click on the *Path* entry.
- Once you've selected the *Path* entry, click the *Edit..* button.
- This will display the *Edit environment variable* window.  Click on the *New* button.
- This will enable editing on a new line in the list.  Type **C:\Toolbelt** and press the Enter/Return key.
- Click the *OK* button to close this window.  Click the *OK* button on the *Environment Variables* window to close it. Click *OK* on the *System Properties* window to close it.

For installation and further configuration / usage, please refer to the documentation for individual tool.

## Tools

- [at.exe](tools/at)- At Process    
- [audio.exe](tools/audio) - Audio Tool    
- [basic.exe](tools/basic) - BASIC Scripting Tool    
- [download.exe](tools/download) - Download Tool    
- [email.exe](tools/email) - Email Tool    
- [ftpsync.exe](tools/ftpsync) - FTP Sync Tool  
- [riff.exe](tools/riff) - RIFF Tool    
- [ta.exe](tools/ta) - Time Announce Process   
- [weather.exe](tools/weather) - Weather Tool  

Please click here for additional [third-party tools](third-party) designed for third-party products.

## Additional Information

[End User License Agreement](/license) 