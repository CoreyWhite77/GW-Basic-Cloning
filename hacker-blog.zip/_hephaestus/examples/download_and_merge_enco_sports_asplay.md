---
layout: page
title: Enco Sports
grand_parent: Overview
parent: Examples
nav_order: 100
---

# Project 'Hephaestus' - Example #1

In this example we want to accoplish the following:

- Automatically download as-play files from an FTP site each morning at about 6am.
- If there is a separate "sports" log for a particular station, merge it with the primary as-play file.

Upon completion, we should have a a file that is prepared to be imported into the traffic and billing system.  