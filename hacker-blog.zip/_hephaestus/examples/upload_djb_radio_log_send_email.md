---
layout: page
title: Traffic->DJB->Email
grand_parent: Overview
parent: Examples
nav_order: 101
---

# Project 'Hephaestus' - Example #2

In this example we want to accomplish the following:

- Upon the log being generated and locked (in the traffic system)...
- Upload the file to an FTP server...
- Send an email notification that the file is ready (to the automation team).
