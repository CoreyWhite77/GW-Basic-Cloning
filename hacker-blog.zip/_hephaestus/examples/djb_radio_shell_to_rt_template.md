---
layout: page
title: Shell->Template
grand_parent: Overview
parent: Examples
nav_order: 103
---

# Project 'Hephaestus' - Example #3

In this example we want to accomplish the following:

- Whenever we are notified that the DJB Radio automation team has updated one or more of their 'shells'...
- Download copy of DJB Radio *database*...
- Extract the 'shell' number into a local CSV formatted file...
- Import this 'shell' into RT as a new/updated named template.

Upon completion, we should now have the template available in RT so that we can easily apply it to a log.  